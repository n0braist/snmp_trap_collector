<?php

/**
 * The base action from which all EventDB module actions inherit.
 */
class EventDBBaseAction extends IcingaBaseAction
{

}

?>