<?php

/**
 * The base model from which all EventDB module models inherit.
 */
class EventDBBaseModel extends IcingaBaseModel
{

}

?>