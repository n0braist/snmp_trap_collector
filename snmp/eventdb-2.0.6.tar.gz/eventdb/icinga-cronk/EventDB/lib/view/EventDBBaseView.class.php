<?php

/**
 * The base view from which all EventDB module views inherit.
 */
class EventDBBaseView extends IcingaBaseView
{

}

?>