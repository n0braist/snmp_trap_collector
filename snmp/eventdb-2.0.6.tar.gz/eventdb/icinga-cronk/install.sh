#!/bin/bash
php ./phing.php install-cronk