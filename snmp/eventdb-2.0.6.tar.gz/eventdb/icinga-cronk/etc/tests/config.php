<?php

AgaviConfig::set('core.testing_dir', realpath(dirname(__FILE__)));
AgaviConfig::set('core.app_dir','/usr/local/icinga-web/app/');
AgaviConfig::set('core.root_dir', "/usr/local/icinga-web/");

?>
