INSERT INTO event (
    ack, 
    priority, 
    facility, 
    host_name, 
    type, 
    program, 
    message, 
    modified, 
    host_address, 
    created
) VALUES (
    0,
    0, 
    20, 
    "mail-bak", 
    2, 
    "mail", 
    "I am random 580522", 
    NULL, 
    NULL, 
    NULL
);
